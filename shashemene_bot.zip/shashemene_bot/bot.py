import os, re, logging
import openpyxl
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(level=logging.INFO)
TOKEN = os.environ["BOT_TOKEN"]
DATA = os.environ.get("DATA_FILE", "data.xlsx")

# (label, actual_col, target_col, pct_col) — 0-based columns of PERFORMANCE sheet
PRODUCTS = {
    "merchant": ("Merchant E-birr+CBS", 1, 2, 3),
    "coopay":   ("Coopay E-birr", 8, 9, 10),
    "agent":    ("Agent", 11, 12, 13),
    "card":     ("Card Banking", 18, 19, 20),
    "michu":    ("Michu", 21, 22, 23),
    "pos":      ("POS 5K+5TXN", 24, 25, 26),
}

def num(v):
    if v is None: return 0.0
    if isinstance(v, (int, float)): return float(v)
    s = re.sub(r"[,%\s]", "", str(v))
    try: return float(s)
    except ValueError: return 0.0

def pct(v):
    if isinstance(v, (int, float)): return v * 100 if v <= 3 else v
    return num(v)

def load():
    wb = openpyxl.load_workbook(DATA, data_only=True)
    ws = wb["PERFORMANCE"]
    rows, total = {}, None
    for r in ws.iter_rows(min_row=6, values_only=True):
        name = (r[0] or "").strip()
        if not name: continue
        if name.lower().startswith("total"):
            total = r; break
        rows[name] = r
    area = {}
    for i, sh in enumerate(["AREA M 1", "AREA M2", "AREA M3"], 1):
        for r in wb[sh].iter_rows(min_row=6, values_only=True):
            n = (r[0] or "").strip()
            if n and not n.lower().startswith("total"): area[n.lower()] = i
    return rows, total, area

ROWS, TOTAL, AREA = load()
ICON = lambda p: "🟢" if p >= 100 else ("🟡" if p >= 70 else "🔴")

def line(r, key):
    label, a, t, p = PRODUCTS[key]
    return f"{ICON(pct(r[p]))} {label}: {num(r[a]):,.0f} / {num(r[t]):,.0f} ({pct(r[p]):.0f}%)"

def card(name, r):
    a = AREA.get(name.lower(), "?")
    out = [f"📍 {name}  (Area Manager {a})", "YTD Jul 1 – Oct 17, 2026", ""]
    out += [line(r, k) for k in PRODUCTS]
    out += ["", f"Merchant amount: {num(r[6]):,.0f} ETB | Txn: {num(r[7]):,.0f}",
            f"Agent amount: {num(r[16]):,.0f} ETB | Txn: {num(r[17]):,.0f}"]
    return "\n".join(out)

def find(q):
    q = q.lower().strip()
    hits = [n for n in ROWS if q in n.lower()]
    return hits

HELP = ("Shashemene District Digital Performance Bot\n\n"
        "/district – district totals\n"
        "/branch <name> – full branch card\n"
        "/area <1|2|3> – area manager branches\n"
        "/top <product> [n] – best branches\n"
        "/bottom <product> [n] – weakest branches\n"
        "/below <product> – branches under 70%\n\n"
        "Products: " + ", ".join(PRODUCTS))

async def start(u: Update, c: ContextTypes.DEFAULT_TYPE):
    await u.message.reply_text(HELP)

async def district(u, c):
    out = ["🏦 SHASHAMANE DISTRICT — YTD (Jul 1 – Oct 17, 2026)", ""]
    out += [line(TOTAL, k) for k in PRODUCTS]
    await u.message.reply_text("\n".join(out))

async def branch(u, c):
    q = " ".join(c.args)
    if not q: return await u.message.reply_text("Usage: /branch Robe")
    hits = find(q)
    if not hits: return await u.message.reply_text("No branch found.")
    if len(hits) > 1 and q.lower() not in [h.lower() for h in hits]:
        return await u.message.reply_text("Which one?\n" + "\n".join(hits[:15]))
    n = next((h for h in hits if h.lower() == q.lower()), hits[0])
    await u.message.reply_text(card(n, ROWS[n]))

async def area(u, c):
    if not c.args or c.args[0] not in "123":
        return await u.message.reply_text("Usage: /area 1")
    k = int(c.args[0])
    out = [f"Area Manager {k}", ""]
    for n, r in ROWS.items():
        if AREA.get(n.lower()) == k:
            out.append(f"{ICON(pct(r[3]))} {n}: Merchant {pct(r[3]):.0f}% | Coopay {pct(r[10]):.0f}% | Agent {pct(r[13]):.0f}% | Card {pct(r[20]):.0f}%")
    await send_long(u, "\n".join(out))

def rank(args, reverse):
    if not args or args[0].lower() not in PRODUCTS: return None, None, None
    key = args[0].lower()
    n = int(args[1]) if len(args) > 1 and args[1].isdigit() else 10
    p = PRODUCTS[key][3]
    items = [(nm, pct(r[p]), r) for nm, r in ROWS.items()]
    items.sort(key=lambda x: x[1], reverse=reverse)
    return key, items[:n], PRODUCTS[key][0]

async def top(u, c):
    key, items, label = rank(c.args, True)
    if not key: return await u.message.reply_text("Usage: /top merchant 10")
    a = PRODUCTS[key][1]
    await send_long(u, f"🏆 Top {label}\n\n" + "\n".join(f"{i}. {n} — {p:.0f}% ({num(r[a]):,.0f})" for i, (n, p, r) in enumerate(items, 1)))

async def bottom(u, c):
    key, items, label = rank(c.args, False)
    if not key: return await u.message.reply_text("Usage: /bottom card 10")
    a = PRODUCTS[key][1]
    await send_long(u, f"⚠️ Weakest {label}\n\n" + "\n".join(f"{i}. {n} — {p:.0f}% ({num(r[a]):,.0f})" for i, (n, p, r) in enumerate(items, 1)))

async def below(u, c):
    if not c.args or c.args[0].lower() not in PRODUCTS:
        return await u.message.reply_text("Usage: /below coopay")
    key = c.args[0].lower(); p = PRODUCTS[key][3]
    items = sorted([(n, pct(r[p])) for n, r in ROWS.items() if pct(r[p]) < 70], key=lambda x: x[1])
    await send_long(u, f"🔴 {PRODUCTS[key][0]} below 70% ({len(items)} branches)\n\n" + "\n".join(f"{n} — {v:.0f}%" for n, v in items))

async def send_long(u, text):
    for i in range(0, len(text), 3800):
        await u.message.reply_text(text[i:i+3800])

def main():
    app = Application.builder().token(TOKEN).build()
    for name, fn in [("start", start), ("help", start), ("district", district), ("branch", branch),
                     ("area", area), ("top", top), ("bottom", bottom), ("below", below)]:
        app.add_handler(CommandHandler(name, fn))
    app.run_polling()

if __name__ == "__main__":
    main()
