DEPLOY (10 minutes, free)
1. Telegram > @BotFather > /newbot > copy the token. Your bot link will be t.me/<username_you_choose>.
2. Put this folder on GitHub, then Railway.app or Render.com > New > Background Worker (Docker).
3. Add environment variable BOT_TOKEN = your token. Deploy.
4. To update data: replace data.xlsx (same sheet layout) and redeploy.
Local test: pip install -r requirements.txt; BOT_TOKEN=xxx python bot.py
